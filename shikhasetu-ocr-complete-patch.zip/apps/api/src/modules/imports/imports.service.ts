import {
  Injectable,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';

import { randomBytes } from 'crypto';
import { Prisma } from '../../generated/prisma/client';
import { PrismaService } from '../../database/prisma.service';
import { CreateQuestionDto } from '../questions/dto/create-question.dto';

import { parse } from 'csv-parse/sync';
import * as XLSX from 'xlsx';

type ImportFile = Express.Multer.File;
type ImportData = Record<string, unknown>;

@Injectable()
export class ImportsService {
  constructor(private readonly prisma: PrismaService) {}

  private normalizeText(value: string): string {
    return value
      .normalize('NFKC')
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  private isValidUuid(value: unknown): value is string {
    return (
      typeof value === 'string' &&
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
        value,
      )
    );
  }

  private parseJsonValue(value: unknown): unknown {
    if (typeof value !== 'string') {
      return value;
    }

    const trimmed = value.trim();

    if (!trimmed) {
      return undefined;
    }

    try {
      return JSON.parse(trimmed);
    } catch {
      return value;
    }
  }

  private parseFile(file: ImportFile): ImportData[] {
    const extension = file.originalname.split('.').pop()?.toLowerCase();

    let rows: unknown[];

    try {
      if (extension === 'json') {
        const parsed = JSON.parse(file.buffer.toString('utf8'));
        rows = Array.isArray(parsed) ? parsed : parsed?.questions;
      } else if (extension === 'csv') {
        rows = parse(file.buffer, {
          columns: true,
          skip_empty_lines: true,
          bom: true,
          trim: true,
          relax_column_count: false,
        });
      } else if (extension === 'xlsx' || extension === 'xls') {
        const workbook = XLSX.read(file.buffer, { type: 'buffer' });
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];

        if (!firstSheet) {
          throw new BadRequestException(
            'Excel file does not contain a worksheet.',
          );
        }

        rows = XLSX.utils.sheet_to_json(firstSheet, {
          defval: '',
          raw: false,
        });
      } else {
        throw new BadRequestException(
          'Unsupported file format. Use JSON, CSV or XLSX.',
        );
      }
    } catch (error) {
      if (error instanceof BadRequestException) {
        throw error;
      }

      throw new BadRequestException(
        'Unable to read the uploaded file. Please check its format.',
      );
    }

    if (!Array.isArray(rows)) {
      throw new BadRequestException(
        'Invalid file structure. JSON must contain an array or a questions array.',
      );
    }

    if (rows.length === 0) {
      throw new BadRequestException(
        'The uploaded file does not contain any question rows.',
      );
    }

    if (rows.length > 10000) {
      throw new BadRequestException(
        'Maximum 10000 rows are allowed per import batch.',
      );
    }

    return rows.map((row, index) => {
      if (
        typeof row !== 'object' ||
        row === null ||
        Array.isArray(row)
      ) {
        throw new BadRequestException(
          `Invalid data structure at row ${index + 1}.`,
        );
      }

      const data = { ...(row as ImportData) };

      // optionA-D contain the four choices.
      // optionE contains the correct answer letter (A/B/C/D).
      // Legacy JSON options remain supported.
      if (!('options' in data)) {
        const letters = ['A', 'B', 'C', 'D'];

        const correctOption = String(
          data.optionE ?? '',
        ).trim().toUpperCase();

        const flatOptions: ImportData[] = [];

        letters.forEach((letter, index) => {
          const optionText = String(
            data[`option${letter}`] ?? '',
          ).trim();

          if (optionText) {
            flatOptions.push({
              label: letter,
              optionText,
              isCorrect: correctOption === letter,
              sortOrder: index + 1,
            });
          }
        });

        if (flatOptions.length > 0) {
          data.options = flatOptions;
        }

        if (
          (!data.correctAnswer ||
            !String(data.correctAnswer).trim()) &&
          correctOption
        ) {
          const selected = flatOptions.find(
            (option) => option.label === correctOption,
          );

          if (selected) {
            data.correctAnswer = selected.optionText;
          }
        }
      }
      // Separate exam columns -> occurrences array.
      // Existing JSON occurrences remain supported.
      if (!('occurrences' in data)) {
        const institution = String(
          data.institution ?? '',
        ).trim();

        const examName = String(
          data.examName ?? '',
        ).trim();

        const examId = String(
          data.examId ?? '',
        ).trim();

        if (institution || examName || examId) {
          const occurrence: ImportData = {
            institution,
            ...(examName ? { examName } : {}),
            ...(String(data.examYear ?? '').trim()
              ? { examYear: Number(data.examYear) }
              : {}),
            ...(data.postName
              ? { postName: String(data.postName).trim() }
              : {}),
            ...(data.department
              ? { department: String(data.department).trim() }
              : {}),
            ...(String(data.questionNumber ?? '').trim()
              ? { questionNumber: Number(data.questionNumber) }
              : {}),
            ...(data.source
              ? { source: String(data.source).trim() }
              : {}),
            ...(String(data.sourcePage ?? '').trim()
              ? { sourcePage: Number(data.sourcePage) }
              : {}),
            ...(data.sourceUrl
              ? { sourceUrl: String(data.sourceUrl).trim() }
              : {}),
            ...(data.institutionId
              ? { institutionId: String(data.institutionId).trim() }
              : {}),
            ...(examId ? { examId } : {}),
            ...(data.postId
              ? { postId: String(data.postId).trim() }
              : {}),
            ...(data.sourceDocumentId
              ? {
                  sourceDocumentId: String(
                    data.sourceDocumentId,
                  ).trim(),
                }
              : {}),
          };

          data.occurrences = [occurrence];
        }
      }

      if ('options' in data) {
        data.options = this.parseJsonValue(data.options);
      }

      if ('occurrences' in data) {
        data.occurrences = this.parseJsonValue(data.occurrences);
      }

      return data;
    });
  }

  private validateRow(data: ImportData): string[] {
    const errors: string[] = [];

    const questionText = data.questionText;
    const subject = data.subject;
    const topic = data.topic;

    if (
      typeof questionText !== 'string' ||
      !questionText.trim()
    ) {
      errors.push('Question text is required.');
    } else if (questionText.length > 1000) {
      errors.push('Question text cannot exceed 1000 characters.');
    }

    if (typeof subject !== 'string' || !subject.trim()) {
      errors.push('Subject is required.');
    } else if (subject.length > 200) {
      errors.push('Subject cannot exceed 200 characters.');
    }

    if (typeof topic !== 'string' || !topic.trim()) {
      errors.push('Topic is required.');
    } else if (topic.length > 200) {
      errors.push('Topic cannot exceed 200 characters.');
    }

    const questionType = data.questionType ?? 'MCQ';

    const allowedTypes = [
      'MCQ',
      'TRUE_FALSE',
      'FILL_IN_THE_BLANKS',
      'WRITTEN',
    ];

    if (
      typeof questionType !== 'string' ||
      !allowedTypes.includes(questionType)
    ) {
      errors.push('Invalid question type.');
    }

    const difficulty = data.difficulty ?? 'MEDIUM';

    if (!['EASY', 'MEDIUM', 'HARD'].includes(String(difficulty))) {
      errors.push('Invalid difficulty.');
    }

    const status = data.status ?? 'DRAFT';

    if (
      !['DRAFT', 'PUBLISHED', 'HIDDEN', 'ARCHIVED'].includes(
        String(status),
      )
    ) {
      errors.push('Invalid question status.');
    }

    const options = data.options;

    if (options !== undefined && options !== null) {
      if (!Array.isArray(options)) {
        errors.push('Options must be an array.');
      } else {
        if (options.length < 2 || options.length > 10) {
          errors.push('Options must contain 2 to 10 items.');
        }

        const labels = new Set<string>();
        let correctCount = 0;

        options.forEach((option, index) => {
          if (
            typeof option !== 'object' ||
            option === null ||
            Array.isArray(option)
          ) {
            errors.push(`Option ${index + 1} is invalid.`);
            return;
          }

          const item = option as ImportData;

          if (
            typeof item.label !== 'string' ||
            !item.label.trim()
          ) {
            errors.push(`Option ${index + 1} requires a label.`);
          } else {
            const label = item.label.trim().toUpperCase();

            if (labels.has(label)) {
              errors.push(`Duplicate option label: ${label}.`);
            }

            labels.add(label);
          }

          if (
            typeof item.optionText !== 'string' ||
            !item.optionText.trim()
          ) {
            errors.push(`Option ${index + 1} requires option text.`);
          }

          if (
            item.isCorrect !== undefined &&
            typeof item.isCorrect !== 'boolean'
          ) {
            errors.push(
              `Option ${index + 1} has invalid isCorrect value.`,
            );
          }

          if (item.isCorrect === true) {
            correctCount++;
          }
        });

        if (
          questionType === 'MCQ' &&
          correctCount !== 1
        ) {
          errors.push(
            'MCQ must have exactly one correct option.',
          );
        }
      }
    } else if (questionType === 'MCQ') {
      errors.push('MCQ questions require options.');
    }

    const occurrences = data.occurrences;

    if (!Array.isArray(occurrences) || occurrences.length < 1) {
      errors.push('At least one occurrence is required.');
    } else {
      occurrences.forEach((occurrence, index) => {
        if (
          typeof occurrence !== 'object' ||
          occurrence === null ||
          Array.isArray(occurrence)
        ) {
          errors.push(`Occurrence ${index + 1} is invalid.`);
          return;
        }

        const item = occurrence as ImportData;
        const hasExamId =
          typeof item.examId === 'string' && item.examId.trim() !== '';

        if (
          typeof item.institution !== 'string' ||
          !item.institution.trim()
        ) {
          errors.push(
            `Occurrence ${index + 1}: institution is required.`,
          );
        }

        // Exam-linked occurrences get examName and examYear
        // directly from the Exam record.
        if (!hasExamId) {
          if (
            typeof item.examName !== 'string' ||
            !item.examName.trim()
          ) {
            errors.push(
              `Occurrence ${index + 1}: exam name is required.`,
            );
          }

          const year = Number(item.examYear);

          if (
            !Number.isInteger(year) ||
            year < 1900 ||
            year > 2100
          ) {
            errors.push(
              `Occurrence ${index + 1}: exam year must be between 1900 and 2100.`,
            );
          }
        } else if (!this.isValidUuid(item.examId)) {
          errors.push(
            `Occurrence ${index + 1}: invalid Exam ID.`,
          );
        }

        if (
          item.institutionId !== undefined &&
          item.institutionId !== null &&
          item.institutionId !== '' &&
          !this.isValidUuid(item.institutionId)
        ) {
          errors.push(
            `Occurrence ${index + 1}: invalid Institution ID.`,
          );
        }

        if (
          item.postId !== undefined &&
          item.postId !== null &&
          item.postId !== '' &&
          !this.isValidUuid(item.postId)
        ) {
          errors.push(
            `Occurrence ${index + 1}: invalid Post ID.`,
          );
        }

        if (
          item.sourceDocumentId !== undefined &&
          item.sourceDocumentId !== null &&
          item.sourceDocumentId !== '' &&
          !this.isValidUuid(item.sourceDocumentId)
        ) {
          errors.push(
            `Occurrence ${index + 1}: invalid Source Document ID.`,
          );
        }
      });
    }

    if (
      data.correctAnswer !== undefined &&
      typeof data.correctAnswer !== 'string'
    ) {
      errors.push('Correct answer must be text.');
    }

    if (
      data.explanation !== undefined &&
      typeof data.explanation !== 'string'
    ) {
      errors.push('Explanation must be text.');
    }

    return errors;
  }

  /**
   * Validates Exam references during preview.
   * The Exam record is the source of truth for linked occurrences.
   */
  private async validateOccurrenceReferences(
    data: ImportData,
  ): Promise<string[]> {
    const errors: string[] = [];

    if (!Array.isArray(data.occurrences)) {
      return errors;
    }

    for (let index = 0; index < data.occurrences.length; index++) {
      const occurrence = data.occurrences[index];

      if (
        typeof occurrence !== 'object' ||
        occurrence === null ||
        Array.isArray(occurrence)
      ) {
        continue;
      }

      const item = occurrence as ImportData;

      if (
        typeof item.examId !== 'string' ||
        !item.examId.trim() ||
        !this.isValidUuid(item.examId)
      ) {
        continue;
      }

      const exam = await this.prisma.exam.findUnique({
        where: {
          id: item.examId,
        },
        select: {
          id: true,
          institutionId: true,
          postId: true,
          name: true,
          examYear: true,
        },
      });

      if (!exam) {
        errors.push(
          `Occurrence ${index + 1}: selected Exam does not exist.`,
        );
        continue;
      }

      if (
        item.institutionId &&
        item.institutionId !== exam.institutionId
      ) {
        errors.push(
          `Occurrence ${index + 1}: Institution ID does not match the selected Exam.`,
        );
      }

      if (
        item.postId &&
        item.postId !== exam.postId
      ) {
        errors.push(
          `Occurrence ${index + 1}: Post ID does not match the selected Exam.`,
        );
      }
    }

    return errors;
  }

  /**
   * Resolves an occurrence from its Exam record.
   * Legacy occurrences without examId remain unchanged.
   */
  private async resolveOccurrenceForImport(
    tx: Prisma.TransactionClient,
    occurrence: CreateQuestionDto['occurrences'][number],
  ) {
    if (!occurrence.examId) {
      return {
        institution: occurrence.institution,
        examName: occurrence.examName,
        examYear: occurrence.examYear,
        postName: occurrence.postName,
        department: occurrence.department,
        questionNumber: occurrence.questionNumber,
        source: occurrence.source,
        sourcePage: occurrence.sourcePage,
        sourceUrl: occurrence.sourceUrl,
        institutionId: occurrence.institutionId,
        examId: null,
        postId: occurrence.postId,
        sourceDocumentId: occurrence.sourceDocumentId,
      };
    }

    const exam = await tx.exam.findUnique({
      where: {
        id: occurrence.examId,
      },
      select: {
        id: true,
        institutionId: true,
        postId: true,
        name: true,
        examYear: true,
      },
    });

    if (!exam) {
      throw new BadRequestException(
        'Selected Exam does not exist.',
      );
    }

    if (
      occurrence.institutionId &&
      occurrence.institutionId !== exam.institutionId
    ) {
      throw new BadRequestException(
        'Institution ID does not match the selected Exam.',
      );
    }

    if (
      occurrence.postId &&
      occurrence.postId !== exam.postId
    ) {
      throw new BadRequestException(
        'Post ID does not match the selected Exam.',
      );
    }

    return {
      institution: occurrence.institution,
      examName: exam.name,
      examYear: exam.examYear,
      postName: occurrence.postName,
      department: occurrence.department,
      questionNumber: occurrence.questionNumber,
      source: occurrence.source,
      sourcePage: occurrence.sourcePage,
      sourceUrl: occurrence.sourceUrl,
      institutionId: exam.institutionId,
      examId: exam.id,
      postId: exam.postId,
      sourceDocumentId: occurrence.sourceDocumentId,
    };
  }

  /**
   * Creates a question using the current transaction.
   * Question, options and occurrences are committed together.
   */
  private async createQuestionInTransaction(
    tx: Prisma.TransactionClient,
    dto: CreateQuestionDto,
  ) {
    const questionType = dto.questionType ?? 'MCQ';

    if (
      questionType === 'MCQ' &&
      (!dto.options || dto.options.length < 2)
    ) {
      throw new BadRequestException(
        'MCQ questions must have at least two options.',
      );
    }

    if (questionType === 'MCQ') {
      const correctOptions =
        dto.options?.filter((option) => option.isCorrect) ?? [];

      if (correctOptions.length !== 1) {
        throw new BadRequestException(
          'MCQ questions must have exactly one correct option.',
        );
      }
    }

    const questionCode =
      `Q-${Date.now()}-${randomBytes(3).toString('hex').toUpperCase()}`;

    let selectedSubject: {
      id: string;
      name: string;
      isActive: boolean;
    } | null = null;

    let selectedTopic: {
      id: string;
      name: string;
      subjectId: string;
      isActive: boolean;
      subject: {
        id: string;
        name: string;
        isActive: boolean;
      };
    } | null = null;

    if (dto.subjectId) {
      selectedSubject = await tx.subject.findFirst({
        where: {
          id: dto.subjectId,
          isActive: true,
        },
        select: {
          id: true,
          name: true,
          isActive: true,
        },
      });

      if (!selectedSubject) {
        throw new BadRequestException(
          'Selected Subject does not exist or is inactive.',
        );
      }
    }

    if (dto.topicId) {
      selectedTopic = await tx.topic.findFirst({
        where: {
          id: dto.topicId,
          isActive: true,
        },
        include: {
          subject: {
            select: {
              id: true,
              name: true,
              isActive: true,
            },
          },
        },
      });

      if (!selectedTopic || !selectedTopic.subject.isActive) {
        throw new BadRequestException(
          'Selected Topic does not exist or its Subject is inactive.',
        );
      }

      if (
        selectedSubject &&
        selectedTopic.subjectId !== selectedSubject.id
      ) {
        throw new BadRequestException(
          'Selected Topic must belong to the selected Subject.',
        );
      }

      if (!selectedSubject) {
        selectedSubject = selectedTopic.subject;
      }
    }

    // Resolve all occurrence references inside the same transaction.
    const resolvedOccurrences = await Promise.all(
      dto.occurrences.map((occurrence) =>
        this.resolveOccurrenceForImport(tx, occurrence),
      ),
    );

    return tx.question.create({
      data: {
        questionCode,
        questionText: dto.questionText,
        questionType,
        subject: selectedSubject?.name ?? dto.subject,
        topic: selectedTopic?.name ?? dto.topic,
        ...(selectedSubject
          ? { subjectRef: { connect: { id: selectedSubject.id } } }
          : {}),
        ...(selectedTopic
          ? { topicRef: { connect: { id: selectedTopic.id } } }
          : {}),
        correctAnswer: dto.correctAnswer,
        explanation: dto.explanation,
        difficulty: dto.difficulty ?? 'MEDIUM',
        status: dto.status ?? 'DRAFT',

        options: {
          create: (dto.options ?? []).map((option) => ({
            label: option.label,
            optionText: option.optionText,
            isCorrect: option.isCorrect ?? false,
            sortOrder: option.sortOrder ?? 0,
          })),
        },

        occurrences: {
          create: resolvedOccurrences,
        },
      },
    });
  }

  async preview(file: ImportFile) {
    if (!file) {
      throw new BadRequestException('No file uploaded.');
    }

    if (!file.buffer || file.size === 0) {
      throw new BadRequestException('Uploaded file is empty.');
    }

    const rows = this.parseFile(file);

    const batch = await this.prisma.importBatch.create({
      data: {
        fileName: file.originalname,
        fileType:
          file.originalname.split('.').pop()?.toLowerCase() ??
          'unknown',
        status: 'PROCESSING',
        totalRows: rows.length,
        startedAt: new Date(),
      },
    });

    const preparedRows: Prisma.ImportRowCreateManyInput[] = [];

    let validRows = 0;
    let invalidRows = 0;
    let duplicateRows = 0;

    const seenQuestions = new Set<string>();

    try {
      for (let index = 0; index < rows.length; index++) {
        const row = rows[index];

        const errors = this.validateRow(row);

        if (errors.length === 0) {
          const referenceErrors =
            await this.validateOccurrenceReferences(row);

          errors.push(...referenceErrors);
        }

        let rowStatus: 'VALID' | 'INVALID' | 'DUPLICATE' = 'VALID';

        if (errors.length > 0) {
          rowStatus = 'INVALID';
          invalidRows++;
        } else {
          const questionText = String(row.questionText);
          const normalized = this.normalizeText(questionText);

          if (seenQuestions.has(normalized)) {
            rowStatus = 'DUPLICATE';
            errors.push(
              'Duplicate question found within this import file.',
            );
            duplicateRows++;
          } else {
            seenQuestions.add(normalized);

            const existing = await this.prisma.question.findFirst({
              where: {
                deletedAt: null,
                questionText: {
                  equals: questionText,
                  mode: 'insensitive',
                },
              },
              select: {
                id: true,
              },
            });

            if (existing) {
              rowStatus = 'DUPLICATE';
              errors.push(
                'An identical question already exists in the question bank.',
              );
              duplicateRows++;
            } else {
              validRows++;
            }
          }
        }

        preparedRows.push({
          batchId: batch.id,
          rowNumber: index + 1,
          rawData: row as Prisma.InputJsonValue,
          status: rowStatus,
          errorMessages:
            errors.length > 0
              ? (errors as Prisma.InputJsonValue)
              : Prisma.JsonNull,
        });
      }

      const updatedBatch = await this.prisma.$transaction(
        async (tx) => {
          await tx.importRow.createMany({
            data: preparedRows,
          });

          return tx.importBatch.update({
            where: {
              id: batch.id,
            },
            data: {
              status: 'REVIEW',
              validRows,
              invalidRows,
              duplicateRows,
              completedAt: new Date(),
            },
          });
        },
      );

      return {
        success: true,
        message: 'Import preview generated successfully.',
        data: {
          batch: updatedBatch,
          summary: {
            totalRows: rows.length,
            validRows,
            invalidRows,
            duplicateRows,
          },
        },
      };
    } catch (error) {
      await this.prisma.importBatch.update({
        where: {
          id: batch.id,
        },
        data: {
          status: 'FAILED',
          errorSummary: {
            message:
              error instanceof Error
                ? error.message
                : 'Unknown import error',
          },
          completedAt: new Date(),
        },
      });

      throw error;
    }
  }

  async findAll(page = 1, limit = 20) {
    const safePage = Math.max(1, page);
    const safeLimit = Math.min(100, Math.max(1, limit));

    const [data, total] = await this.prisma.$transaction([
      this.prisma.importBatch.findMany({
        orderBy: {
          createdAt: 'desc',
        },
        skip: (safePage - 1) * safeLimit,
        take: safeLimit,
        include: {
          _count: {
            select: {
              rows: true,
            },
          },
        },
      }),
      this.prisma.importBatch.count(),
    ]);

    return {
      success: true,
      data,
      pagination: {
        total,
        page: safePage,
        limit: safeLimit,
        totalPages: Math.ceil(total / safeLimit),
      },
    };
  }

  async findOne(id: string) {
    const batch = await this.prisma.importBatch.findUnique({
      where: {
        id,
      },
      include: {
        rows: {
          orderBy: {
            rowNumber: 'asc',
          },
        },
      },
    });

    if (!batch) {
      throw new NotFoundException('Import batch not found.');
    }

    return {
      success: true,
      data: batch,
    };
  }

  async findRows(
    batchId: string,
    status?: string,
    page = 1,
    limit = 50,
  ) {
    const batch = await this.prisma.importBatch.findUnique({
      where: {
        id: batchId,
      },
      select: {
        id: true,
      },
    });

    if (!batch) {
      throw new NotFoundException('Import batch not found.');
    }

    const safePage = Math.max(1, page);
    const safeLimit = Math.min(100, Math.max(1, limit));

    const where: Prisma.ImportRowWhereInput = {
      batchId,
    };

    if (status) {
      const allowedStatuses = [
        'PENDING',
        'VALID',
        'INVALID',
        'DUPLICATE',
        'IMPORTED',
        'SKIPPED',
      ];

      if (!allowedStatuses.includes(status)) {
        throw new BadRequestException(
          'Invalid import row status.',
        );
      }

      where.status =
        status as Prisma.EnumImportRowStatusFilter['equals'];
    }

    const [data, total] = await this.prisma.$transaction([
      this.prisma.importRow.findMany({
        where,
        orderBy: {
          rowNumber: 'asc',
        },
        skip: (safePage - 1) * safeLimit,
        take: safeLimit,
      }),
      this.prisma.importRow.count({
        where,
      }),
    ]);

    return {
      success: true,
      data,
      pagination: {
        total,
        page: safePage,
        limit: safeLimit,
        totalPages: Math.ceil(total / safeLimit),
      },
    };
  }

  async commit(batchId: string, rowIds?: string[]) {
    const where: Prisma.ImportRowWhereInput = {
      batchId,
      status: 'VALID',
    };

    if (rowIds && rowIds.length > 0) {
      where.id = {
        in: rowIds,
      };
    }

    // Atomically claim the batch. Only one request can move
    // a REVIEW batch into PROCESSING.
    const rows = await this.prisma.$transaction(async (tx) => {
      const claimed = await tx.importBatch.updateMany({
        where: {
          id: batchId,
          status: 'REVIEW',
        },
        data: {
          status: 'PROCESSING',
          startedAt: new Date(),
          completedAt: null,
        },
      });

      if (claimed.count !== 1) {
        const existing = await tx.importBatch.findUnique({
          where: {
            id: batchId,
          },
          select: {
            id: true,
          },
        });

        if (!existing) {
          throw new NotFoundException('Import batch not found.');
        }

        throw new BadRequestException(
          'This batch is not available for processing. It may already be processing.',
        );
      }

      const selectedRows = await tx.importRow.findMany({
        where,
        orderBy: {
          rowNumber: 'asc',
        },
      });

      if (selectedRows.length === 0) {
        throw new BadRequestException(
          'No valid rows available for import.',
        );
      }

      return selectedRows;
    });

    let importedRows = 0;
    let failedRows = 0;

    for (const row of rows) {
      try {
        const dto = row.rawData as unknown as CreateQuestionDto;

        await this.prisma.$transaction(async (tx) => {
          const question = await this.createQuestionInTransaction(
            tx,
            dto,
          );

          const updatedRow = await tx.importRow.updateMany({
            where: {
              id: row.id,
              batchId,
              status: 'VALID',
            },
            data: {
              status: 'IMPORTED',
              questionId: question.id,
              errorMessages: Prisma.JsonNull,
            },
          });

          if (updatedRow.count !== 1) {
            throw new BadRequestException(
              'Import row is no longer available for processing.',
            );
          }
        });

        importedRows++;
      } catch (error) {
        const errorMessage =
          error instanceof Error
            ? error.message
            : 'Question import failed.';

        const failedUpdate = await this.prisma.importRow.updateMany({
          where: {
            id: row.id,
            batchId,
            status: 'VALID',
          },
          data: {
            status: 'INVALID',
            errorMessages: [errorMessage],
          },
        });

        if (failedUpdate.count === 1) {
          failedRows++;
        }
      }
    }

    const finalBatch = await this.prisma.$transaction(async (tx) => {
      const remainingValid = await tx.importRow.count({
        where: {
          batchId,
          status: 'VALID',
        },
      });

      const updated = await tx.importBatch.updateMany({
        where: {
          id: batchId,
          status: 'PROCESSING',
        },
        data: {
          status: remainingValid > 0 ? 'REVIEW' : 'COMPLETED',
          importedRows: {
            increment: importedRows,
          },
          invalidRows: {
            increment: failedRows,
          },
          completedAt: new Date(),
        },
      });

      if (updated.count !== 1) {
        throw new BadRequestException(
          'Import batch status changed unexpectedly.',
        );
      }

      return tx.importBatch.findUniqueOrThrow({
        where: {
          id: batchId,
        },
      });
    });

    const remainingValidRows = await this.prisma.importRow.count({
      where: {
        batchId,
        status: 'VALID',
      },
    });

    return {
      success: true,
      message: 'Import processing completed.',
      data: {
        batch: finalBatch,
        importedRows,
        failedRows,
        remainingValidRows,
      },
    };
  }

  async skipRows(batchId: string, rowIds: string[]) {
    if (!Array.isArray(rowIds) || rowIds.length === 0) {
      throw new BadRequestException(
        'At least one row ID must be provided.',
      );
    }

    return this.prisma.$transaction(async (tx) => {
      // Lock/claim the REVIEW batch before changing its rows.
      const claimed = await tx.importBatch.updateMany({
        where: {
          id: batchId,
          status: 'REVIEW',
        },
        data: {
          skippedRows: {
            increment: 0,
          },
        },
      });

      if (claimed.count !== 1) {
        const batch = await tx.importBatch.findUnique({
          where: {
            id: batchId,
          },
          select: {
            id: true,
          },
        });

        if (!batch) {
          throw new NotFoundException('Import batch not found.');
        }

        throw new BadRequestException(
          'Rows can only be skipped while the batch is in REVIEW status.',
        );
      }

      const result = await tx.importRow.updateMany({
        where: {
          batchId,
          id: {
            in: rowIds,
          },
          status: {
            in: ['VALID', 'INVALID', 'DUPLICATE'],
          },
        },
        data: {
          status: 'SKIPPED',
        },
      });

      if (result.count > 0) {
        await tx.importBatch.update({
          where: {
            id: batchId,
          },
          data: {
            skippedRows: {
              increment: result.count,
            },
          },
        });
      }

      return {
        success: true,
        message: 'Selected rows skipped successfully.',
        data: {
          skippedRows: result.count,
        },
      };
    });
  }
}