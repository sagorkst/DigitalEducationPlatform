﻿import { IsString, MinLength, MaxLength } from 'class-validator';

export class ChangeMyPasswordDto {
  @IsString()
  @MinLength(1)
  @MaxLength(128)
  currentPassword!: string;

  @IsString()
  @MinLength(8)
  @MaxLength(128)
  newPassword!: string;
}
