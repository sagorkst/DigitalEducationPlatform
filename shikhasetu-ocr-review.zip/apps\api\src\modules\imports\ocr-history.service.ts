﻿import {
  Injectable,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';

import { Prisma } from '../../generated/prisma/client';
import { PrismaService } from '../../database/prisma.service';

export type OcrHistoryRowStatus =
  | 'PENDING'
  | 'VALID'
  | 'INVALID'
  | 'DUPLICATE'
  | 'IMPORTED'
  | 'SKIPPED';

@Injectable()
export class OcrHistoryService {
  constructor(private readonly prisma: PrismaService) {}

  async createBatch(
    file: Express.Multer.File,
    questions: Record<string, unknown>[],
  ) {
    if (!file || !questions.length) {
      throw new BadRequestException(
        'OCR file and extracted questions are required.',
      );
    }

    const extension =
      file.originalname.split('.').pop()?.toLowerCase() ?? 'unknown';

    return this.prisma.$transaction(async (tx) => {
      const batch = await tx.importBatch.create({
        data: {
          fileName: file.originalname,
          fileType: `${extension}-ocr`,
          status: 'REVIEW',
          totalRows: questions.length,
          validRows: 0,
          invalidRows: 0,
          duplicateRows: 0,
          importedRows: 0,
          skippedRows: 0,
          startedAt: new Date(),
        },
      });

      await tx.importRow.createMany({
        data: questions.map((question, index) => ({
          batchId: batch.id,
          rowNumber: index + 1,
          rawData: question as unknown as Prisma.InputJsonValue,
          status: 'PENDING',
        })),
      });

      const rows = await tx.importRow.findMany({
        where: { batchId: batch.id },
        select: {
          id: true,
          rowNumber: true,
        },
        orderBy: {
          rowNumber: 'asc',
        },
      });

      return {
        batchId: batch.id,
        rows,
      };
    });
  }

  async updateRow(
    batchId: string,
    rowId: string,
    status: OcrHistoryRowStatus,
    errorMessages?: unknown,
    questionId?: string | null,
  ) {
    const allowedStatuses: OcrHistoryRowStatus[] = [
      'PENDING',
      'VALID',
      'INVALID',
      'DUPLICATE',
      'IMPORTED',
      'SKIPPED',
    ];

    if (!allowedStatuses.includes(status)) {
      throw new BadRequestException('Invalid OCR row status.');
    }

    return this.prisma.$transaction(async (tx) => {
      const row = await tx.importRow.findFirst({
        where: {
          id: rowId,
          batchId,
        },
      });

      if (!row) {
        throw new NotFoundException(
          'OCR import row was not found.',
        );
      }

      if (row.status === 'IMPORTED' && status !== 'IMPORTED') {
        throw new BadRequestException(
          'An imported OCR question cannot be reverted.',
        );
      }

      await tx.importRow.update({
        where: { id: rowId },
        data: {
          status,
          ...(questionId !== undefined ? { questionId } : {}),
          ...(errorMessages !== undefined
            ? {
                errorMessages:
                  errorMessages === null
                    ? Prisma.DbNull
                    : (errorMessages as Prisma.InputJsonValue),
              }
            : {}),
        },
      });

      const rows = await tx.importRow.findMany({
        where: { batchId },
        select: { status: true },
      });

      const count = (value: string) =>
        rows.filter((item) => item.status === value).length;

      const totalRows = rows.length;

      const isCompleted =
        totalRows > 0 &&
        rows.every((item) =>
          ['IMPORTED', 'SKIPPED', 'DUPLICATE'].includes(item.status),
        );

      return tx.importBatch.update({
        where: { id: batchId },
        data: {
          totalRows,
          validRows: count('VALID'),
          invalidRows: count('INVALID'),
          duplicateRows: count('DUPLICATE'),
          importedRows: count('IMPORTED'),
          skippedRows: count('SKIPPED'),
          status: isCompleted ? 'COMPLETED' : 'REVIEW',
          completedAt: isCompleted ? new Date() : null,
        },
      });
    });
  }
}
